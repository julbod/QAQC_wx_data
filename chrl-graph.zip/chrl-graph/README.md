# Read Me
- This is a web app that pulls weather station data from a database and visualizes it using Plotly in R.
- Available here: http://graph.viu-hydromet-wx.ca/
- Example of interactive graphs: 

![Screenshot from 2021-09-18 17-56-29](https://user-images.githubusercontent.com/45050185/133911360-8c4f5165-8f59-423d-8654-7a3433caab9a.png)
![Screenshot from 2021-09-18 17-50-02](https://user-images.githubusercontent.com/45050185/133911361-f7a89548-94bb-46c9-bd83-30e43d7c92c6.png)
