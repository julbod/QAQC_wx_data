custom.r is the modified custom.r original file but modified to show the clean vs qaqc.
the app.R code has also been modified to only show these plots.
The custom_ORIGINAL.r is the original file from GitHub. Make sure you don't sync GitHub with this folder!!