#### qaqc graphs ####

output$header4 <- renderUI({
  req(input$qaqc_site)
  str1 <- paste0("<h2>", station_meta[[input$qaqc_site]][1], " (", station_meta[[input$qaqc_site]][2], " m)", "</h2>")
  if(input$qaqc_site %in% list_stn_tipping_bucket_errs){
    HTML(paste(str1, p('The tipping bucket is currently malfunctioning at this station please refer to total precipitation (precip pipe) instead.', style = "color:red")))
  }
  else{HTML(paste(str1))}
})


# pull data from mysql db based on user station and year input
qaqc_data_query <- reactive({
  req(input$qaqc_site)
  req(input$qaqc_year)

  # Connect to the first database
  conn1 <- do.call(DBI::dbConnect, args)
  on.exit(DBI::dbDisconnect(conn1))
  query1 <- paste0("SELECT * FROM clean_", input$qaqc_site, " WHERE WatYr = ", input$qaqc_year, ";")
  data1 <- dbGetQuery(conn1, query1)

  # Connect to the second database
  conn2 <- do.call(DBI::dbConnect, args)
  on.exit(DBI::dbDisconnect(conn2))
  query2 <- paste0("SELECT * FROM qaqc_", input$qaqc_site, " WHERE WatYr = ", input$qaqc_year, ";")
  data2 <- dbGetQuery(conn2, query2)

  # Combine data from both databases
  data <- bind_rows(data1, data2)
})


# reactive element to create year list based on available years for chosen station
observe({
  # need to find the year range of selected sites. finds the max of the two start years as the min.
  start_years <- station_meta[[input$qaqc_site]][3]
  min_year <- unname(unlist(lapply(start_years, max)))
  max_year <- weatherdash::wtr_yr(Sys.Date(), 10) # return current water year.
  year_range <- seq.int(min_year, max_year, by = 1)
  updateSelectInput(session, "qaqc_year", "Select Water Year:", year_range, selected = max_year)
})


# only plot button for snow depth only
output$varSelection_qaqc <- renderUI({
  radioButtons(inputId = "qaqc_var", label = "Select one variable: ", choices = c("Snow_Depth"), inline = FALSE, selected = "Snow_Depth")
})


#filter preset data query
qaqcDataFilter <-  reactive({
  req(input$sliderTimeRange_qaqc)
  df <- qaqc_data_query()
  df %>%  filter(DateTime >= input$sliderTimeRange_qaqc[1] & DateTime <= input$sliderTimeRange_qaqc[2])
})

# final data set
finalData_qaqc <- reactive({
  req(qaqcDataFilter())
  df <- qaqcDataFilter()
  return(df)
})


# plot for qaqc graphs page
output$plot5 <- renderPlotly({
  req(finalData_qaqc())
  req(input$qaqc_site)
  req(input$qaqc_year)

  df <- finalData_qaqc()

  plot_ly() %>%
    add_trace(
    data = df[df$Database == "Database1", ],
    x = ~plotTime,
    y = ~Snow_Depth,
    text = ~DateTime,
    color = ~as.factor(df[df$Database == "Database1", ]$WatYr),
    type = "scatter",
    mode = "lines",
    name = "Clean_SQL",
    line = list(color = 'blue'),  # Set the line color for Database1
    hovertemplate = paste('<b>%{text}</b><br>%{yaxis.title.text}: %{y}<extra></extra>')
  ) %>%
  add_trace(
    data = df[df$Database == "Database2", ],
    x = ~plotTime,
    y = ~Snow_Depth,
    text = ~DateTime,
    color = ~as.factor(df[df$Database == "Database2", ]$WatYr),
    type = "scatter",
    mode = "lines",
    name = "QAQC_SQL",
    line = list(color = 'red'),  # Set the line color for Database2
    hovertemplate = paste('<b>%{text}</b><br>%{yaxis.title.text}: %{y}<extra></extra>')
  ) %>%
  layout(
    xaxis = c(generalAxLayout,
                list(title = "",
                     type = 'date',
                     tickformat = "%b %d"
                )),
    yaxis = c(generalAxLayout, list(title = "<b>Snow Depth</b>")),
    margin = list(r = 50, l = 50),
    plot_bgcolor = "#f5f5f5",
    paper_bgcolor = "#f5f5f5",
    hovermode = 'x'
  )
})

#### render partner logo ui ####
output$partnerLogoUI_qaqc <- renderUI({
  req(input$qaqc_site)
  cur_stn <- input$qaqc_site
  station_meta[[cur_stn]]['logos']
})

# create warning for down stations
observe({
  req(preset_data_query())
  req(input$qaqc_site)
  if(input$smenu == "qaqc_graph"){
    if(input$qaqc_site %in% down_stations){
      showModal(modalDialog(
        title = "Warning:",
        paste("This station is currently offline."),
        easyClose = T
      ))
    }
  }
}
)