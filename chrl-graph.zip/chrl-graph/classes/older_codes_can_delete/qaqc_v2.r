#### QAQC Comparisons ####

output$header4 <- renderUI({
  req(input$qaqc_site)
  str1 <- paste0("<h2>", station_meta[[input$qaqc_site]][1], " (", station_meta[[input$qaqc_site]][2], " m)", "</h2>")
  HTML(paste(str1))
})

# reactive element to create year list based on available years for chosen station
observe({
  # need to find the year range of selected sites. finds the max of the two start years as the min.
  start_years_qaqc <- station_meta[[input$qaqc_site]][3]
  min_year <- unname(unlist(lapply(start_years_qaqc, max)))
  max_year <- wtr_yr(Sys.Date(), 10)
  year_range <- seq.int(min_year, max_year, by = 1)
  updateSelectInput(session, "compare_year", "Select Water Years to Compare: ", year_range, selected = c(max_year, (max_year-1)))
})

# get available variables for selected station
# note that this will provide all variables as options but currently code only provides Snow Depth so all buttons will plot Snow Depth
#output$varSelection_qaqc <- renderUI({
#  # get colnames from reactive dataset
#  stnVars <- unname(unlist(station_meta[[input$qaqc_site]][6]))

#  var_subset <- Filter(function(x) any(stnVars %in% x), varsDict)

#  radioButtons(inputId = "compare_var", label = "Select one variable: ", choices = var_subset, inline = FALSE, selected = "SWE")
#})

# only plot button for snow depth only
output$varSelection_qaqc <- renderUI({
  radioButtons(inputId = "compare_var", label = "Select one variable: ", choices = c("Snow_Depth"), inline = FALSE, selected = "Snow_Depth")
})

qaqc_data_query <- reactive({
  req(input$qaqc_site)
  
  withProgress(message = 'Requesting Data... ', value = 1, {
    # Connect to the first database
    conn1 <- do.call(DBI::dbConnect, args)
    on.exit(DBI::dbDisconnect(conn1))
    query1 <- paste0("SELECT DateTime, WatYr, Snow_Depth, 'Database1' AS `Database` FROM clean_", input$qaqc_site, ";")
    data1 <- dbGetQuery(conn1, query1) %>%
      mutate(
        plotTime = if_else(month(DateTime) < 10,
                           weatherdash::set_yr(DateTime, 1901),
                           weatherdash::set_yr(DateTime, 1900)))

    # Connect to the second database
    conn2 <- do.call(DBI::dbConnect, args)
    on.exit(DBI::dbDisconnect(conn2))
    query2 <- paste0("SELECT DateTime, WatYr, Snow_Depth, 'Database2' AS `Database` FROM qaqc_", input$qaqc_site, ";")
    data2 <- dbGetQuery(conn2, query2) %>%
      mutate(
        plotTime = if_else(month(DateTime) < 10,
                           weatherdash::set_yr(DateTime, 1901),
                           weatherdash::set_yr(DateTime, 1900)))

    # Combine data from both databases
    data <- bind_rows(data1, data2)

    # Filter by selected years using distinct
    data <- data %>% filter(WatYr %in% input$compare_year) %>%
      distinct(DateTime, WatYr, Snow_Depth, Database, .keep_all = TRUE)

  })
})

output$plot3 <- renderPlotly({
  req(qaqc_data_query())
  req(input$qaqc_site)
  req(input$compare_year)

  df <- qaqc_data_query()

  plot_ly() %>%
    add_trace(
      data = df[df$Database == "Database1", ],
      x = ~plotTime,
      y = ~Snow_Depth,
      text = ~DateTime,
      color = ~as.factor(df[df$Database == "Database1", ]$WatYr),
      type = "scatter",
      mode = "lines",
      name = "Clean_SQL",
      line = list(color = 'blue'),  # Set the line color for Database1
      hovertemplate = paste('<b>%{text}</b><br>%{yaxis.title.text}: %{y}<extra></extra>')
    ) %>%
    add_trace(
      data = df[df$Database == "Database2", ],
      x = ~plotTime,
      y = ~Snow_Depth,
      text = ~DateTime,
      color = ~as.factor(df[df$Database == "Database2", ]$WatYr),
      type = "scatter",
      mode = "lines",
      name = "QAQC_SQL",
      line = list(color = 'red'),  # Set the line color for Database2
      hovertemplate = paste('<b>%{text}</b><br>%{yaxis.title.text}: %{y}<extra></extra>')
    ) %>%
    layout(
      xaxis = c(generalAxLayout,
                list(title = "",
                     type = 'date',
                     tickformat = "%b %d"
                )),
      yaxis = c(generalAxLayout, list(title = "<b>Snow Depth</b>")),
      margin = list(r = 50, l = 50),
      plot_bgcolor = "#f5f5f5",
      paper_bgcolor = "#f5f5f5",
      hovermode = 'x'
    )
})