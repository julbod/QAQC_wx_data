#### qaqc graphs ####

output$header4 <- renderUI({
  req(input$qaqc_site)
  str1 <- paste0("<h2>", station_meta[[input$qaqc_site]][1], " (", station_meta[[input$qaqc_site]][2], " m)", "</h2>")
  if(input$qaqc_site %in% list_stn_tipping_bucket_errs){
    HTML(paste(str1, p('The tipping bucket is currently malfunctioning at this station please refer to total precipitation (precip pipe) instead.', style = "color:red")))
  }
  else{HTML(paste(str1))}
})


# pull data from mysql db based on user station and year input
qaqc_data_query <- reactive({
  req(input$qaqc_site)
  req(input$qaqc_year)

  # Connect to the first database
  conn1 <- do.call(DBI::dbConnect, args)
  on.exit(DBI::dbDisconnect(conn1))
  query1 <- paste0("SELECT * FROM clean_", input$qaqc_site, " WHERE WatYr = ", input$qaqc_year, ";")
  data1 <- dbGetQuery(conn1, query1)

  # Connect to the second database
  conn2 <- do.call(DBI::dbConnect, args)
  on.exit(DBI::dbDisconnect(conn2))
  query2 <- paste0("SELECT * FROM qaqc_", input$qaqc_site, " WHERE WatYr = ", input$qaqc_year, ";")
  data2 <- dbGetQuery(conn2, query2)

  # Combine data from both databases
  data <- bind_rows(data1, data2)
})

# pull data from mysql db based on user station and year input
#qaqc_data_query <- reactive({
#  req(input$qaqc_site)
#  req(input$qaqc_year)

#  conn <- do.call(DBI::dbConnect, args)
#  on.exit(DBI::dbDisconnect(conn))
#  query <- paste0("SELECT * FROM clean_", input$custom_site,  " where WatYr = ", input$custom_year, ";")
#  data <- dbGetQuery(conn, query)
#
#})

# reactive element to create year list based on available years for chosen station
observe({
  # need to find the year range of selected sites. finds the max of the two start years as the min.
  start_years <- station_meta[[input$qaqc_site]][3]
  min_year <- unname(unlist(lapply(start_years, max)))
  max_year <- weatherdash::wtr_yr(Sys.Date(), 10) # return current water year.
  year_range <- seq.int(min_year, max_year, by = 1)
  updateSelectInput(session, "qaqc_year", "Select Water Year:", year_range, selected = max_year)
})

# get available variables for selected station
#output$varSelection_qaqc <- renderUI({
#  # get colnames from reactive dataset
#  stnVars <- unname(unlist(station_meta[[input$qaqc_site]][6]))

#  var_subset <- Filter(function(x) any(stnVars %in% x), varsDict)

#  checkboxGroupInput(inputId = "qaqc_var", label = "Select one or two variables:", choices = var_subset, inline = FALSE, selected = "Air_Temp")
#})

#output$cleanSnowButton_qaqc <- renderUI({
#  req(input$qaqc_var)
#  if("Snow_Depth" %in% input$qaqc_var){
#    radioButtons("cleanSnowQaqc", "Preform automated spike correction on Snow Depth?:", inline = T,
#                 c("Yes" = "yes",
#                   "No" = "no"),
#                 selected = "no"
#    )
#  }

#})

# only plot button for snow depth only
output$varSelection_qaqc <- renderUI({
  radioButtons(inputId = "qaqc_var", label = "Select one variable: ", choices = c("Snow_Depth"), inline = FALSE, selected = "Snow_Depth")
})

# ensure only two variables are selected
#observe({
#  if(length(input$qaqc_var) > 2){
#    updateCheckboxGroupInput(session, "qaqc_var", selected = tail(input$qaqc_var, 2))
#  }
#})

#output$slider_qaqc <- renderUI({
#  req(qaqc_data_query())
#  sliderInput(inputId = "sliderTimeRange", label = "",
#              min = min(qaqc_data_query()$DateTime),
#              max = max(qaqc_data_query()$DateTime),
#              value = c(min(qaqc_data_query()$DateTime),
#                        max(qaqc_data_query()$DateTime)),
#              step = 3600,
#              width = '85%',
#              height )
#})

#filter preset data query
qaqcDataFilter <-  reactive({
  req(input$sliderTimeRange_qaqc)
  df <- qaqc_data_query()
  df %>%  filter(DateTime >= input$sliderTimeRange_qaqc[1] & DateTime <= input$sliderTimeRange_qaqc[2])
})

# final data set
finalData_qaqc <- reactive({
  req(qaqcDataFilter())
  #req(input$qaqc_var)

  df <- qaqcDataFilter()

  #if("Snow_Depth" %in% input$qaqc_var) {
  #  req(input$cleanSnowQaqc)
  #  if(input$cleanSnowQaqc == "yes"){
  #    flag  <- ("Snow_Depth" %in% input$qaqc_var)
  #    clean <- input$cleanSnow
  #    df <- spike_clean(data = df, 'DateTime', 'Snow_Depth', spike_th = 10, roc_hi_th = 40, roc_low_th = 75)
  #  }
  #  else{return(df)}
  #}
  return(df)
})


# plot for qaqc graphs page
output$plot5 <- renderPlotly({
  req(input$qaqc_site)
  req(input$qaqc_year)
  #req(input$qaqc_var)
  req(finalData_qaqc())

#  df <- finalData_qaqc() %>%
#    select(DateTime, input$qaqc_var)
  df <- finalData_qaqc()

#  varNames <- names(Filter(function(x) unlist(x) %in% input$qaqc_var, varsDict))

#  if(length(input$qaqc_var) == 2){
#    weatherdash::graph_two(
#      data = df,
#      x = "DateTime",
#      y1 = 2,
#      y2 = 3, 
#      y1_name = varNames[1], 
#      y2_name = varNames[2]
#    )
#  } else {
#    weatherdash::graph_one(
#      data = df,
#      x = "DateTime",
#      y1 = 2,
#      y1_name = varNames[1]
#    )
#  }
#})

plot_ly() %>%
    add_trace(
      data = df[df$Database == "Database1", ],
      x = ~plotTime,
      y = ~Snow_Depth,
      text = ~DateTime,
      color = ~as.factor(df[df$Database == "Database1", ]$WatYr),
      type = "scatter",
      mode = "lines",
      name = "Clean_SQL",
      line = list(color = 'blue'),  # Set the line color for Database1
      hovertemplate = paste('<b>%{text}</b><br>%{yaxis.title.text}: %{y}<extra></extra>')
    ) %>%
    add_trace(
      data = df[df$Database == "Database2", ],
      x = ~plotTime,
      y = ~Snow_Depth,
      text = ~DateTime,
      color = ~as.factor(df[df$Database == "Database2", ]$WatYr),
      type = "scatter",
      mode = "lines",
      name = "QAQC_SQL",
      line = list(color = 'red'),  # Set the line color for Database2
      hovertemplate = paste('<b>%{text}</b><br>%{yaxis.title.text}: %{y}<extra></extra>')
    ) %>%
    layout(
      xaxis = c(generalAxLayout,
                list(title = "",
                     type = 'date',
                     tickformat = "%b %d"
                )),
      yaxis = c(generalAxLayout, list(title = "<b>Snow Depth</b>")),
      margin = list(r = 50, l = 50),
      plot_bgcolor = "#f5f5f5",
      paper_bgcolor = "#f5f5f5",
      hovermode = 'x'
    )
})

#### render partner logo ui ####
output$partnerLogoUI_qaqc <- renderUI({
  req(input$qaqc_site)
  cur_stn <- input$qaqc_site
  station_meta[[cur_stn]]['logos']
})

# create warning for down stations
observe({
  req(preset_data_query())
  req(input$qaqc_site)
  if(input$smenu == "qaqc_graph"){
    if(input$qaqc_site %in% down_stations){
      showModal(modalDialog(
        title = "Warning:",
        paste("This station is currently offline."),
        easyClose = T
      ))
    }
  }
}
)